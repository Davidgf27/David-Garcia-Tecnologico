import React, { useState } from 'react'

function Form() {
    const [Datos, setDatos] = useState({
        id:'',
        name:'',
        edad:''
    })
    const cambio=(e)=>{
        const{name,value}=e.target
        setDatos({
            ...Datos,
            [name]:value
        })
    }
    const mostrar=()=>{
        console.log(Datos)
    }
  return (
    <div>
      <form onSubmit={mostrar}>
        <input type="text" name='id' value={Datos.id} onChange={cambio}placeholder='id'/>
        <input type="text" name='nombre' value={Datos.nombre} onChange={cambio} placeholder='nombre' />
        <input type="number" name='edad' value={Datos.edad} onChange={cambio} placeholder='edad'/>
        <button>Enviar</button>

      </form>

    </div>
  )
}

export default Form

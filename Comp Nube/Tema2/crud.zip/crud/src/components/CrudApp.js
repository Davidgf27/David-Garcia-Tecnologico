import React, { useState } from 'react'
import CrudForm from './CrudForm'
import CrudTable from './CrudTable'
const coches=[
  {id:1,
    modelo:'march',
    marca:'nissan'
  },
  {id:2,
    modelo:'romeo',
    marca:'romeo'
  },
  {id:3,
    modelo:'camaro',
    marca:'ford'
  },
  {id:4,
    modelo:'vento',
    marca:'vw'
  },
  {id:5,
    modelo:'mini copeer',
    marca:'mini'
  },
]
const CrudApp = () => {
  const [bd, setBd] = useState(coches)
  const [dataToEdit, setDataToEdit] = useState(null)


  const createData=(data)=>{
    data.id=Date.now();
    setBd([...bd,data]);

  }

  const updateData=(data)=>{
    let newData=bd.map(el=> el.id===data.id? data:el);
    setBd(newData);
  }

  const deleteData=(id)=>{
    let isDelete=window.confirm(`estas seguro de eliminar ${id}`)
    if(isDelete){
      let newData= bd.filter((el)=>el.id!==id);
      setBd(newData);
    }else{
      return
    }

  }
  return (
    <div>
      <h2>Crud</h2>
      <h3>{dataToEdit?"Editar":"Agregar"}</h3>
      <CrudForm createData={createData} updateData={updateData} dataToEdit={dataToEdit} setDataToEdit={setDataToEdit}/>
      <CrudTable data={bd} setDataToEdit={setDataToEdit} deleteData={deleteData}/>
    </div>
  )
}

export default CrudApp

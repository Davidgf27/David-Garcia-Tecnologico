import React from 'react'

const CrudTableRow = ({elemento,setDataToEdit,deleteData}) => {
    let {marca,modelo,id}=elemento;

    return (
    <tr>
    <td>{modelo}</td>
    <td>{marca}</td>
    <td>
        <button onClick={()=>setDataToEdit(elemento)}>Editar</button>
        <button onClick={()=>deleteData(id)}>Eliminar</button>
    </td>
    </tr>
    )
}

export default CrudTableRow

import React, { useState } from 'react'

import { useEffect } from 'react'
const initialCoches={
  modelo:'',
  marca:'',
  id:null
}
const CrudForm = ({createData,updateData,dataToEdit,setDataToEdit}) => {
    const [form, setForm] = useState(initialCoches)
    useEffect(()=>{
      if(dataToEdit){
        setForm(dataToEdit)
      }else{
        setForm(initialCoches)
      }
    },[dataToEdit]);
    const handleChange=(e)=>{
      setForm({
        ...form,
        [e.target.name]:e.target.value, 
      });
    }
    const handleSubmit=(e)=>{
      e.preventDefault();
      if(!form.marca || !form.modelo){
        alert("Datos incompletos")
        return;
      }
      if(form.id===null){
        createData(form)
      }else{
        updateData(form)
      }
      handleReset();
    }
    const handleReset=(e)=>{
      setForm(initialCoches);
      setDataToEdit(null);
    }

  return (

    <div>
    <form class="form">
        <h3>Ingresar Datos</h3>
        <input type='text' name='modelo' placeholder='modelo' onChange={handleChange} value={form.modelo}/>
        <input type='text' name='marca' placeholder='marca' onChange={handleChange} value={form.marca}/>
        <input type='submit' value='Enviar' onClick={handleSubmit}></input>
        <input type='reset' value='Limpiar' onClick={handleReset}></input>
    </form>
    </div>
  )
}

export default CrudForm

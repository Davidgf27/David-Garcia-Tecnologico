import React from 'react'
import CrudApp from "./components/CrudApp";
import CrudForm from './components/CrudForm';

function App() {
 
  return (
    <div>
     <h1>CrudApp</h1> 
      <CrudApp/>
      
    </div>
  );
}

export default App;

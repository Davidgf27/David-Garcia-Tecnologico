import styles from './page.module.css'
import Link from 'next/link'

export default function Home() {
    return (
        <main className={styles.main}>
            <div className="container text-center">
                <h1 className="display-4 my-5">Game Planet</h1>
                <div className="row">
                    <div className="col-md-4">
                        <Link href="/plataformas" legacyBehavior>
                            <a className="btn btn-primary btn-lg w-100">
                                Ver Plataformas
                            </a>
                        </Link>
                    </div>
                    <div className="col-md-4">
                        <Link href="/categorias" legacyBehavior>
                            <a className="btn btn-success btn-lg w-100">
                                Ver Categorias
                            </a>
                        </Link>
                    </div>
                    <div className="col-md-4">
                        <Link href="/juegos" legacyBehavior>
                            <a className="btn btn-info btn-lg w-100">
                                Ver Juegos
                            </a>
                        </Link>
                    </div>
                </div>
            </div>
        </main>
    )
}

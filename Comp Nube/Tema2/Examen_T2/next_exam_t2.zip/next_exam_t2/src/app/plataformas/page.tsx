"use client";

import Link from 'next/link';
import {useEffect, useState} from 'react';
import axios from 'axios';


const Plataformas = () => {

    const [plataformas, setPlataformas] = useState([]);

    const fetchData = async () => {
        try {
            const response = await axios.get('http://20.106.193.139/examen2/exa_19280887/plataformas.php');
            if (response.status === 200) {
                setPlataformas(response.data);
            } else {
                console.error('Error al obtener los datos de la API');
            }
        } catch (error) {
            console.error('Error al realizar la solicitud a la API:', error);
        }
    };


    useEffect(() => {
        fetchData();
    }, []);

    const handleDelete = async (id: any) => {
        try {
            const response = await axios.delete('http://20.106.193.139/examen2/exa_19280887/plataformas.php?id=' + id);
            if (response.status === 200) {
                // setPlataformas(response.data);
                fetchData()
            } else {
                console.error('Error al obtener los datos de la API');
            }
        } catch (error) {
            console.error('Error al realizar la solicitud a la API:', error);
        }
    }

    return (
        <>
            <div className="container">
                <h1 className="title">Lista de Plataformas</h1>

                <div className="container-sm">
                    <Link href={"/"}>
                        <button className="btn btn-secondary me-1">Regresar al menu</button>
                    </Link>
                    <Link href={"/plataformas/new"}>
                        <button className="btn btn-primary">Agregar nueva plataforma</button>
                    </Link>
                </div>

                <table className="table table-striped">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Acciones</th>
                    </tr>
                    </thead>
                    <tbody>
                    {plataformas.map((plataforma) => (
                        <tr key={plataforma.id}>
                            <td>{plataforma.id}</td>
                            <td>{plataforma.nombre}</td>
                            <td>
                                <Link href={"plataformas/update?id=" + plataforma.id}>
                                    <button className="btn btn-secondary me-2">Editar</button>
                                </Link>
                                <button className="btn btn-danger" onClick={() => {
                                    handleDelete(plataforma.id);
                                }
                                }>Eliminar</button>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
                <style jsx>{`
                  .container {
                    max-width: 800px;
                    margin: 0 auto;
                    padding: 20px;
                    text-align: center;
                  }

                  .title {
                    font-size: 24px;
                    margin-bottom: 20px;
                  }
                `}</style>
            </div>
        </>
    );
};

export default Plataformas;

"use client"

import React, {useEffect, useState} from "react";
import axios from "axios";
import {useRouter} from "next/navigation"


const EditarJuego = () => {

    const router = useRouter()

    const [id, setId] = useState('');
    const [nombre, setNombre] = useState('');
    const [categorias, setCategorias] = useState([])
    const [plataformas, setPlataformas] = useState([])
    const [categoriaSeleccionada, setCategoriaSeleccionada] = useState('');
    const [plataformaSeleccionada, setPlataformaSeleccionada] = useState('');
    const [imagen, setImagen] = useState('');
    const [enabled, setEnabled] = useState(false);

    const fetchData = async () => {
        //llenar la info de el juego seleccionado
        const searchParams = new URLSearchParams(window.location.search);
        const idParam = searchParams.get('id');
        setId(idParam)
        try {
            const response = await axios.get('http://20.106.193.139/examen2/exa_19280887/juegos.php?id=' + idParam);
            if (response.status === 200) {
                let data = response.data
                setNombre(data.nombre)
                setCategoriaSeleccionada(data.id_categoria)
                setPlataformaSeleccionada(data.id_plataforma)
                setImagen(data.imagen)
                setEnabled(true)
            } else {
                console.error('Error al obtener los datos de la API');
            }
        } catch (error) {
            console.error('Error al realizar la solicitud a la API:', error);
        }


        //llenar los selects
        try {
            const urlCategorias = 'http://20.106.193.139/examen2/exa_19280887/categorias.php' + nombre
            console.log(urlCategorias);
            const responseCat = await axios.get(urlCategorias);
            if (responseCat.status === 200) {
                setCategorias(responseCat.data)
                const urlCategorias = 'http://20.106.193.139/examen2/exa_19280887/plataformas.php' + nombre
                console.log(urlCategorias);
                const responsePlat = await axios.get(urlCategorias);
                if (responsePlat.status === 200) {
                    setPlataformas(responsePlat.data)
                } else {
                    console.error('Error al obtener los datos de la API');
                }
            } else {
                console.error('Error al obtener los datos de la API');
            }
        } catch (error) {
            console.error("error" + error)
            // Error en la solicitud.
        }
    };

    useEffect( () => {
        fetchData()
    }, []);

    const handleEditar = async () => {
        try {
            const url = 'http://20.106.193.139/examen2/exa_19280887/juegos.php'
                + '?id='
                +  id
                + '&nombre='
                + encodeURIComponent(nombre)
                + '&id_categoria='
                + categoriaSeleccionada
                + '&id_plataforma='
                + plataformaSeleccionada
                + '&imagen='
                + encodeURIComponent(imagen)
            console.log(url);
            const response = await axios.put(url);
            if (response.status === 200) {
                router.push("/juegos")
            } else {
                console.error('Error al obtener los datos de la API');
            }
            if (response.ok) {
                // La inserción fue exitosa, puedes redirigir al usuario a la lista de juegos u otra página.
            } else {
                // Ocurrió un error durante la inserción.
            }
        } catch (error) {
            console.error("error" + error)
            // Error en la solicitud.
        }
    };

    return (
        <div className="container">
            <h1 className="title">Inserción de Nuevo Juego</h1>
            <form>
                <div className="mb-3">
                    <label htmlFor="nombre" className="form-label">
                        Nombre:
                    </label>
                    <input
                        type="text"
                        className="form-control"
                        id="nombre"
                        value={nombre}
                        onChange={(e) => setNombre(e.target.value)}
                        disabled={!enabled}
                    />
                </div>
                <div className="mb-3">
                    <label htmlFor="categoria" className="form-label">Categoría:</label>
                    <select
                        className="form-select"
                        id="categoria"
                        value={categoriaSeleccionada}
                        onChange={(e) => setCategoriaSeleccionada(e.target.value)}
                        disabled={!enabled}
                    >
                        <option value="">Seleccionar una categoría</option>
                        {categorias.map((categoria) => (
                            <option key={categoria.id} value={categoria.id}>
                                {categoria.nombre}
                            </option>
                        ))}
                    </select>
                </div>
                <div className="mb-3">
                    <label htmlFor="plataforma" className="form-label">Plataforma:</label>
                    <select
                        className="form-select"
                        id="plataforma"
                        value={plataformaSeleccionada}
                        onChange={(e) => setPlataformaSeleccionada(e.target.value)}
                        disabled={!enabled}
                    >
                        <option value="">Seleccionar una plataforma</option>
                        {plataformas.map((plataforma) => (
                            <option key={plataforma.id} value={plataforma.id}>
                                {plataforma.nombre}
                            </option>
                        ))}
                    </select>
                </div>
                <div className="mb-3">
                    <label htmlFor="imagen" className="form-label">
                        Imagen:
                    </label>
                    <input
                        type="text"
                        className="form-control"
                        id="imagen"
                        value={imagen}
                        onChange={(e) => setImagen(e.target.value)}
                        disabled={!enabled}
                    />
                </div>

                <button type="button" className="btn btn-secondary me-1" onClick={() => {
                    router.push("/juegos")
                }}>
                    Cancelar
                </button>
                <button type="button" className="btn btn-primary" onClick={handleEditar}>
                    Insertar Juego
                </button>
            </form>
        </div>
    );
};

export default EditarJuego;

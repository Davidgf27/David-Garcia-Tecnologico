"use client";

import Link from 'next/link';
import {useEffect, useState} from 'react';
import axios from 'axios';

const Juegos = () => {



    const [juegos, setJuegos] = useState([])


    const fetchData = async () => {
        try {
            const response = await axios.get('http://20.106.193.139/examen2/exa_19280887/juegos.php');
            if (response.status === 200) {
                setJuegos(response.data);
            } else {
                console.error('Error al obtener los datos de la API');
            }
        } catch (error) {
            console.error('Error al realizar la solicitud a la API:', error);
        }
    };


    useEffect(() => {
        fetchData();
    }, []);

    const handleDelete = async (id: any) => {
        try {
            const response = await axios.delete('http://20.106.193.139/examen2/exa_19280887/juegos.php?id=' + id);
            if (response.status === 200) {
                // setJuegos(response.data);
                fetchData()
            } else {
                console.error('Error al obtener los datos de la API');
            }
        } catch (error) {
            console.error('Error al realizar la solicitud a la API:', error);
        }
    }

    return (
        <>
            <div className="container">
                <h1 className="title">Lista de Juegos</h1>

                <div className="container-sm">
                    <Link href={"/"}>
                        <button className="btn btn-secondary me-1">Regresar al menu</button>
                    </Link>
                    <Link href={"/juegos/new"}>
                        <button className="btn btn-primary">Agregar nuevo juego</button>
                    </Link>
                </div>

                <table className="table table-striped">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nombre</th>
                        <th>Categoria</th>
                        <th>Plataforma</th>
                        <th>Acciones</th>
                    </tr>
                    </thead>
                    <tbody>
                    {juegos.map((juego) => (
                        <tr key={juego.id}>
                            <td>{juego.id}</td>
                            <td>{juego.nombre}</td>
                            <td>{juego.categoria}</td>
                            <td>{juego.plataforma}</td>
                            <td>
                                <Link href={"juegos/update?id=" + juego.id}>
                                    <button className="btn btn-secondary me-2">Editar</button>
                                </Link>
                                <button className="btn btn-danger" onClick={() => {
                                    handleDelete(juego.id);
                                }
                                }>Eliminar</button>
                            </td>
                        </tr>
                    ))}
                    </tbody>
                </table>
                <style jsx>{`
                  .container {
                    max-width: 800px;
                    margin: 0 auto;
                    padding: 20px;
                    text-align: center;
                  }

                  .title {
                    font-size: 24px;
                    margin-bottom: 20px;
                  }
                `}</style>
            </div>
        </>
    );
};

export default Juegos;

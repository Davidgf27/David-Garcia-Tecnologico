"use client"

import React, {useEffect, useState} from 'react';
import axios from "axios";
import {useRouter} from "next/navigation";


const InsertarJuego = () => {

    const [nombre, setNombre] = useState('');
    const [categorias, setCategorias] = useState([])
    const [plataformas, setPlataformas] = useState([])
    const [categoriaSeleccionada, setCategoriaSeleccionada] = useState('');
    const [plataformaSeleccionada, setPlataformaSeleccionada] = useState('');
    const [imagen, setImagen] = useState('');

    const router = useRouter()

    const fetchData = async () => {
        try {
            const urlCategorias = 'http://20.106.193.139/examen2/exa_19280887/categorias.php' + nombre
            console.log(urlCategorias);
            const responseCat = await axios.get(urlCategorias);
            if (responseCat.status === 200) {
                setCategorias(responseCat.data)
                const urlCategorias = 'http://20.106.193.139/examen2/exa_19280887/plataformas.php' + nombre
                console.log(urlCategorias);
                const responsePlat = await axios.get(urlCategorias);
                if (responsePlat.status === 200) {
                    setPlataformas(responsePlat.data)
                } else {
                    console.error('Error al obtener los datos de la API');
                }
            } else {
                console.error('Error al obtener los datos de la API');
            }
        } catch (error) {
            console.error("error" + error)
            // Error en la solicitud.
        }
    }

    useEffect(() => {
        fetchData()
    }, []);

    const handleInsertar = async () => {
        try {
            const urlJuegos = 'http://20.106.193.139/examen2/exa_19280887/juegos.php?nombre='
                + nombre
                + '&id_categoria='
                + categoriaSeleccionada
                + '&id_plataforma='
                + plataformaSeleccionada
                + '&imagen='
                + imagen
            console.log(urlJuegos);
            const response = await axios.post(urlJuegos);
            if (response.status === 200) {
                router.push("/juegos")
            } else {
                console.error('Error al obtener los datos de la API');
            }
            if (response.ok) {
                // La inserción fue exitosa, puedes redirigir al usuario a la lista de juegos u otra página.
            } else {
                // Ocurrió un error durante la inserción.
            }
        } catch (error) {
            console.error("error" + error)
            // Error en la solicitud.
        }
    };

    return (
        <div className="container">
            <h1 className="title">Inserción de Nuevo Juego</h1>
            <form>
                <div className="mb-3">
                    <label htmlFor="nombre" className="form-label">
                        Nombre:
                    </label>
                    <input
                        type="text"
                        className="form-control"
                        id="nombre"
                        value={nombre}
                        onChange={(e) => setNombre(e.target.value)}
                    />
                </div>
                <div className="mb-3">
                    <label htmlFor="categoria" className="form-label">Categoría:</label>
                    <select
                        className="form-select"
                        id="categoria"
                        value={categoriaSeleccionada}
                        onChange={(e) => setCategoriaSeleccionada(e.target.value)}
                    >
                        <option value="">Seleccionar una categoría</option>
                        {categorias.map((categoria) => (
                            <option key={categoria.id} value={categoria.id}>
                                {categoria.nombre}
                            </option>
                        ))}
                    </select>
                </div>
                <div className="mb-3">
                    <label htmlFor="plataforma" className="form-label">Plataforma:</label>
                    <select
                        className="form-select"
                        id="plataforma"
                        value={plataformaSeleccionada}
                        onChange={(e) => setPlataformaSeleccionada(e.target.value)}
                    >
                        <option value="">Seleccionar una plataforma</option>
                        {plataformas.map((plataforma) => (
                            <option key={plataforma.id} value={plataforma.id}>
                                {plataforma.nombre}
                            </option>
                        ))}
                    </select>
                </div>
                <div className="mb-3">
                    <label htmlFor="imagen" className="form-label">
                        Imagen:
                    </label>
                    <input
                        type="text"
                        className="form-control"
                        id="imagen"
                        value={imagen}
                        onChange={(e) => setImagen(e.target.value)}
                    />
                </div>

                <button type="button" className="btn btn-secondary me-1" onClick={() => {
                    router.push("/juegos")
                }}>
                    Cancelar
                </button>
                <button type="button" className="btn btn-primary" onClick={handleInsertar}>
                    Insertar Juego
                </button>
            </form>
        </div>
    );
};

export default InsertarJuego;

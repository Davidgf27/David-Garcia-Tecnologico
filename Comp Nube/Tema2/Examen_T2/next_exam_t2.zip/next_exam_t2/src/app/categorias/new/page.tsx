"use client"

import React, { useState } from 'react';
import axios from "axios";
import {useRouter} from "next/navigation";
import {ROUTES_MANIFEST} from "next/constants";


const InsertarCategoria = () => {
    const [nombre, setNombre] = useState('');


    const router = useRouter()

    const handleInsertar = async () => {
        try {
            const url = 'http://20.106.193.139/examen2/exa_19280887/categorias.php?nombre=' + nombre
            console.log(url);
            const response = await axios.post(url);
            if (response.status === 200) {
                router.push("/categorias")
            } else {
                console.error('Error al obtener los datos de la API');
            }
            if (response.ok) {
                // La inserción fue exitosa, puedes redirigir al usuario a la lista de categorias u otra página.
            } else {
                // Ocurrió un error durante la inserción.
            }
        } catch (error) {
            console.error("error" + error)
            // Error en la solicitud.
        }
    };

    return (
        <div className="container">
            <h1 className="title">Inserción de Nueva Categoria</h1>
            <form>
                <div className="mb-3">
                    <label htmlFor="nombre" className="form-label">
                        Nombre:
                    </label>
                    <input
                        type="text"
                        className="form-control"
                        id="nombre"
                        value={nombre}
                        onChange={(e) => setNombre(e.target.value)}
                    />
                </div>

                <button type="button" className="btn btn-secondary me-1" onClick={() => {
                    router.push("/categorias")
                }}>
                    Cancelar
                </button>
                <button type="button" className="btn btn-primary" onClick={handleInsertar}>
                    Insertar Categoria
                </button>
            </form>
        </div>
    );
};

export default InsertarCategoria;

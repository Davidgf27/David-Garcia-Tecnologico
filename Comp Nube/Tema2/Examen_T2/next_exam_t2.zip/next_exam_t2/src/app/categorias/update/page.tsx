"use client"

import React, {useEffect, useState} from "react";
import axios from "axios";
import {useRouter} from "next/navigation"


const EditarCategoria = () => {

    const router = useRouter()

    const [id, setId] = useState('');
    const [nombre, setNombre] = useState('');
    const [enabled, setEnabled] = useState(false);

    const fetchData = async () => {
        const searchParams = new URLSearchParams(window.location.search);
        const idParam = searchParams.get('id');
        setId(idParam)
        try {
            const response = await axios.get('http://20.106.193.139/examen2/exa_19280887/categorias.php?id=' + idParam);
            if (response.status === 200) {
                setNombre(response.data.nombre)
                setEnabled(true)
            } else {
                console.error('Error al obtener los datos de la API');
            }
        } catch (error) {
            console.error('Error al realizar la solicitud a la API:', error);
        }
    };

    useEffect( () => {
        fetchData()
    }, []);

    const handleEditar = async () => {
        try {
            const url = 'http://20.106.193.139/examen2/exa_19280887/categorias.php?id=' + id + '&nombre=' + nombre
            console.log(url);
            const response = await axios.put(url);
            if (response.status === 200) {
                router.push("/categorias")
            } else {
                console.error('Error al obtener los datos de la API');
            }
            if (response.ok) {
                // La inserción fue exitosa, puedes redirigir al usuario a la lista de categorias u otra página.
            } else {
                // Ocurrió un error durante la inserción.
            }
        } catch (error) {
            console.error("error" + error)
            // Error en la solicitud.
        }
    };

    return (
        <div className="container">
            <h1 className="title">Edicion de Categoria</h1>
            <form>
                <div className="mb-3">
                    <label htmlFor="nombre" className="form-label">
                        Nombre:
                    </label>
                    <input
                        type="text"
                        className="form-control"
                        id="nombre"
                        value={nombre}
                        onChange={(e) => setNombre(e.target.value)}
                        disabled={!enabled}
                    />
                </div>

                <button type="button" className="btn btn-secondary me-1" onClick={() => {
                    router.push("/categorias")
                }}>
                    Cancelar
                </button>
                <button type="button" className="btn btn-primary" onClick={handleEditar}>
                    Insertar Categoria
                </button>
            </form>
        </div>
    );
};

export default EditarCategoria;
